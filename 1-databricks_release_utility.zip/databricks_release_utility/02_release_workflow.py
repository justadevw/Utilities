# Databricks notebook source
# MAGIC %md
# MAGIC # Databricks Story Release Utility
# MAGIC
# MAGIC Parameter-driven entry point for creating, updating, recreating, deleting,
# MAGIC and running a Databricks workflow. `workflow_action` controls the job itself;
# MAGIC `task_value_behavior` selects the Task Values notebook embedded in that job.

# COMMAND ----------

# MAGIC %run ./01_workflow_manager

# COMMAND ----------

import json
from typing import Any, Dict, Mapping, Optional, Type


# Edit these static values once for your workspace/repository.
GIT_URL = "REPLACE_WITH_YOUR_GIT_REPOSITORY_URL"
GIT_PROVIDER = "GIT_HUB_ENTERPRISE"
TASK_VALUES_BASE_PATH = "/Workspace/Workflow_Task_Values"
TASK_VALUES_TASK_KEY = "set_task_values"


# COMMAND ----------

DEFAULT_TASKS_JSON = json.dumps(
    [
        {
            "task_key": "first_notebook",
            "notebook_path": "/Workspace/Release_Notebooks/First_Notebook",
            "existing_cluster_id": "REPLACE_WITH_CLUSTER_ID",
            "depends_on": [],
        },
        {
            "task_key": "second_notebook",
            "notebook_path": "/Workspace/Release_Notebooks/Second_Notebook",
            "existing_cluster_id": "REPLACE_WITH_CLUSTER_ID",
            "depends_on": ["first_notebook"],
        },
    ],
    indent=2,
)


def ensure_text_widget(name: str, default_value: str, label: str) -> None:
    """Create a text widget only when it does not already exist."""
    try:
        dbutils.widgets.get(name)
    except Exception:
        dbutils.widgets.text(name, default_value, label)


def ensure_dropdown_widget(
    name: str,
    default_value: str,
    choices: list[str],
    label: str,
) -> None:
    """Create a dropdown widget only when it does not already exist."""
    try:
        dbutils.widgets.get(name)
    except Exception:
        dbutils.widgets.dropdown(name, default_value, choices, label)


ensure_dropdown_widget(
    "workflow_action",
    "CREATE",
    ["CREATE", "UPDATE", "RE_CREATE", "DELETE", "RUN"],
    "01 - Workflow action",
)
ensure_text_widget("job_name", "", "02 - Job name")
ensure_text_widget("job_id", "", "03 - Job ID (optional)")
ensure_dropdown_widget(
    "source", "WORKSPACE", ["WORKSPACE", "GIT"], "04 - Notebook source"
)
ensure_dropdown_widget(
    "environment", "DEV", ["DEV", "QA", "PROD"], "05 - Data environment"
)
ensure_dropdown_widget(
    "task_value_behavior",
    "CREATE",
    ["CREATE", "UPDATE", "RE_CREATE"],
    "06 - Task Value behavior",
)
ensure_dropdown_widget(
    "git_reference_type",
    "BRANCH",
    ["BRANCH", "TAG"],
    "07 - Git reference type",
)
ensure_text_widget("git_reference", "main", "08 - Git branch or tag")
ensure_text_widget(
    "task_values_cluster_id",
    "REPLACE_WITH_CLUSTER_ID",
    "09 - Task Values notebook cluster ID",
)
ensure_text_widget("tasks_json", DEFAULT_TASKS_JSON, "10 - Released notebook tasks (JSON)")
ensure_text_widget(
    "job_description",
    "Managed by the Databricks Story Release Utility.",
    "11 - Job description",
)
ensure_text_widget("job_tags_json", "{}", "12 - Additional job tags (JSON)")
ensure_text_widget("max_concurrent_runs", "1", "13 - Maximum concurrent runs")
ensure_text_widget("job_timeout_seconds", "0", "14 - Job timeout in seconds")
ensure_dropdown_widget(
    "run_after_change", "false", ["false", "true"], "15 - Run after CREATE/UPDATE/RE_CREATE"
)
ensure_dropdown_widget(
    "wait_for_run", "false", ["false", "true"], "16 - Wait for run completion"
)
ensure_text_widget("run_timeout_minutes", "120", "17 - Run wait timeout in minutes")
ensure_text_widget("job_parameters_json", "{}", "18 - Run job parameters (JSON)")
ensure_text_widget("idempotency_token", "", "19 - Run idempotency token (optional)")
ensure_dropdown_widget(
    "dry_run", "true", ["true", "false"], "20 - Preview only (recommended first)"
)


# COMMAND ----------

def widget_value(name: str) -> str:
    return dbutils.widgets.get(name).strip()


def parse_json_widget(name: str, expected_type: Type[Any]) -> Any:
    raw_value = dbutils.widgets.get(name)
    try:
        parsed = json.loads(raw_value)
    except json.JSONDecodeError as exc:
        raise WorkflowValidationError(
            f"Widget {name!r} does not contain valid JSON: {exc.msg} "
            f"(line {exc.lineno}, column {exc.colno})."
        ) from exc
    if not isinstance(parsed, expected_type):
        raise WorkflowValidationError(
            f"Widget {name!r} must contain a JSON {expected_type.__name__}."
        )
    return parsed


def parse_optional_job_id(raw_value: str) -> Optional[int]:
    if not raw_value:
        return None
    try:
        job_id = int(raw_value)
    except ValueError as exc:
        raise WorkflowValidationError("job_id must be an integer when supplied.") from exc
    if job_id <= 0:
        raise WorkflowValidationError("job_id must be greater than zero.")
    return job_id


def require_string_mapping(value: Mapping[Any, Any], field_name: str) -> Dict[str, str]:
    if not all(isinstance(key, str) and isinstance(item, str) for key, item in value.items()):
        raise WorkflowValidationError(
            f"{field_name} must contain only string keys and string values."
        )
    return dict(value)


workflow_action = widget_value("workflow_action").upper()
valid_actions = {"CREATE", "UPDATE", "RE_CREATE", "DELETE", "RUN"}
if workflow_action not in valid_actions:
    raise WorkflowValidationError(
        "workflow_action must be one of: " + ", ".join(sorted(valid_actions))
    )

job_name = widget_value("job_name")
job_id = parse_optional_job_id(widget_value("job_id"))
dry_run = parse_bool(widget_value("dry_run"), "dry_run")
run_after_change = parse_bool(
    widget_value("run_after_change"), "run_after_change"
)
wait_for_run = parse_bool(widget_value("wait_for_run"), "wait_for_run")

try:
    run_timeout_minutes = int(widget_value("run_timeout_minutes"))
except ValueError as exc:
    raise WorkflowValidationError("run_timeout_minutes must be an integer.") from exc
if run_timeout_minutes < 1:
    raise WorkflowValidationError("run_timeout_minutes must be at least 1.")

job_parameters = require_string_mapping(
    parse_json_widget("job_parameters_json", dict), "job_parameters_json"
)
idempotency_token = widget_value("idempotency_token") or None

if workflow_action == "CREATE" and job_id is not None:
    raise WorkflowValidationError("CREATE accepts job_name only; leave job_id empty.")
if workflow_action in {"UPDATE", "RE_CREATE", "DELETE", "RUN"} and not (
    job_id or job_name
):
    raise WorkflowValidationError(
        f"{workflow_action} requires job_id, job_name, or both."
    )


manager = DatabricksWorkflowManager()


# COMMAND ----------

definition = None
if workflow_action in {"CREATE", "UPDATE", "RE_CREATE"}:
    if workflow_action == "CREATE" and not job_name:
        raise WorkflowValidationError(
            "job_name is required for CREATE."
        )
    if workflow_action in {"UPDATE", "RE_CREATE"} and not job_name:
        # job_id alone is a valid identifier. Reuse the current name as the
        # desired name when the operator does not supply one.
        target_for_name = manager.find_job(job_id=job_id)
        job_name = target_for_name.settings.name

    source = parse_enum(NotebookSource, widget_value("source"), "source")
    environment = parse_enum(
        ReleaseEnvironment, widget_value("environment"), "environment"
    )
    task_value_behavior = parse_enum(
        TaskValueBehavior,
        widget_value("task_value_behavior"),
        "task_value_behavior",
    )

    tasks_raw = parse_json_widget("tasks_json", list)
    tasks = tuple(NotebookTaskDefinition.from_mapping(item) for item in tasks_raw)
    additional_tags = require_string_mapping(
        parse_json_widget("job_tags_json", dict), "job_tags_json"
    )

    try:
        max_concurrent_runs = int(widget_value("max_concurrent_runs"))
        job_timeout_seconds = int(widget_value("job_timeout_seconds"))
    except ValueError as exc:
        raise WorkflowValidationError(
            "max_concurrent_runs and job_timeout_seconds must be integers."
        ) from exc

    git_reference = None
    if source is NotebookSource.GIT:
        git_reference = GitReference(
            url=GIT_URL,
            provider=GIT_PROVIDER,
            reference_type=parse_enum(
                GitReferenceType,
                widget_value("git_reference_type"),
                "git_reference_type",
            ),
            reference=widget_value("git_reference"),
        )

    definition = WorkflowDefinition(
        job_name=job_name,
        source=source,
        environment=environment,
        task_value_behavior=task_value_behavior,
        task_values_base_path=TASK_VALUES_BASE_PATH,
        task_values_cluster_id=widget_value("task_values_cluster_id"),
        task_values_task_key=TASK_VALUES_TASK_KEY,
        tasks=tasks,
        git_reference=git_reference,
        description=widget_value("job_description"),
        max_concurrent_runs=max_concurrent_runs,
        timeout_seconds=job_timeout_seconds,
        tags=additional_tags,
    )


# COMMAND ----------

if dry_run:
    if definition is not None:
        result: Dict[str, Any] = {
            "status": "DRY_RUN",
            "action": workflow_action,
            "job_id": job_id,
            "job_name": job_name,
            "job_settings": manager.preview(definition),
        }
        if workflow_action in {"UPDATE", "RE_CREATE"}:
            target = manager.find_job(job_id=job_id, job_name=job_name)
            result["resolved_target_job_id"] = target.job_id
    else:
        target = manager.find_job(job_id=job_id, job_name=job_name)
        result = {
            "status": "DRY_RUN",
            "action": workflow_action,
            "job_id": target.job_id,
            "job_name": target.settings.name,
        }
        if workflow_action == "RUN":
            result["note"] = (
                "RUN uses the Task Values notebook already stored in the job. "
                "Use UPDATE or RE_CREATE first to change environment or Task Value behavior."
            )
else:
    if workflow_action == "CREATE":
        assert definition is not None
        result = manager.create_job(definition)
    elif workflow_action == "UPDATE":
        assert definition is not None
        result = manager.update_job(
            definition, job_id=job_id, job_name=job_name
        )
    elif workflow_action == "RE_CREATE":
        assert definition is not None
        result = manager.recreate_job(
            definition, job_id=job_id, job_name=job_name
        )
    elif workflow_action == "DELETE":
        result = manager.delete_job(job_id=job_id, job_name=job_name)
    else:
        result = manager.run_job(
            job_id=job_id,
            job_name=job_name,
            wait=wait_for_run,
            timeout_minutes=run_timeout_minutes,
            job_parameters=job_parameters,
            idempotency_token=idempotency_token,
        )
        result["note"] = (
            "RUN used the Task Values notebook already stored in the job."
        )

    if workflow_action in {"CREATE", "UPDATE", "RE_CREATE"} and run_after_change:
        run_result = manager.run_job(
            job_id=result["job_id"],
            wait=wait_for_run,
            timeout_minutes=run_timeout_minutes,
            job_parameters=job_parameters,
            idempotency_token=idempotency_token,
        )
        result = {"change": result, "run": run_result}

output_json = json.dumps(result, indent=2, default=str)
print(output_json)
dbutils.notebook.exit(output_json)

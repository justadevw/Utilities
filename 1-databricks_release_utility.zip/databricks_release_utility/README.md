# Databricks Story Release Utility

This utility creates and operates multi-task Databricks workflow jobs from two
Databricks source-format Python notebooks:

- `01_workflow_manager.py` contains validation, job construction, lookup,
  create, update, recreate, delete, and run methods.
- `02_release_workflow.py` is the operator notebook. It exposes Databricks
  widgets and dispatches the selected action.

The `.py` source format is the most efficient option here: it is diff-friendly,
works cleanly in Git, and can be imported directly into Databricks as a notebook.

## Resulting workflow structure

The utility creates one workspace-sourced Task Values task followed by the
released notebook tasks:

```text
set_task_values
  -> each root task from tasks_json
       -> remaining tasks according to their explicit depends_on lists
```

For example, `environment=QA` and `task_value_behavior=RE_CREATE` produces:

```text
/Workspace/Workflow_Task_Values/Set_TaskValues_QA_Re_Create
```

The fixed Task Values task key is `set_task_values`. Downstream notebooks that
retrieve values with `dbutils.jobs.taskValues.get(...)` must use that task key.
The utility does not assume or alter the individual key names set inside your
existing Task Values notebooks.

## One-time setup

1. Import `01_workflow_manager.py` and `02_release_workflow.py` into the same
   Databricks workspace folder.
2. Open `02_release_workflow.py` and set these constants:

   ```python
   GIT_URL = "https://your-git-host/organization/repository.git"
   GIT_PROVIDER = "GIT_HUB_ENTERPRISE"
   TASK_VALUES_BASE_PATH = "/Workspace/Workflow_Task_Values"
   TASK_VALUES_TASK_KEY = "set_task_values"
   ```

3. Confirm that the compute resource running the utility has the Databricks SDK
   for Python. If it is not already available, install the `databricks-sdk`
   package on that compute.
4. Confirm that the operator has permission to create/manage jobs and run the
   explicitly selected clusters. For Git releases, the workspace must already
   have credentials for the static repository.

## Main widget inputs

| Widget | Purpose |
| --- | --- |
| `workflow_action` | `CREATE`, `UPDATE`, `RE_CREATE`, `DELETE`, or `RUN` |
| `job_name` | Required for `CREATE`; optional for other actions when `job_id` is supplied |
| `job_id` | Optional exact job identifier; use it when names are duplicated |
| `source` | `WORKSPACE` or `GIT` for the released notebooks |
| `environment` | `DEV`, `QA`, or `PROD`; builds the Task Values notebook path |
| `task_value_behavior` | `CREATE`, `UPDATE`, or `RE_CREATE`; builds the Task Values notebook path |
| `git_reference_type` | `BRANCH` or `TAG` when `source=GIT` |
| `git_reference` | Selected branch or tag name |
| `task_values_cluster_id` | Existing cluster used by the Task Values notebook |
| `tasks_json` | One object per released notebook, including its cluster and dependencies |
| `dry_run` | When `true`, validates and previews without changing Databricks state |

`workflow_action` and `task_value_behavior` are deliberately separate. For
example, you can update an existing job (`workflow_action=UPDATE`) so its data
notebooks perform create behavior (`task_value_behavior=CREATE`).

## `tasks_json` contract

Each notebook is an object in a JSON array:

```json
{
  "task_key": "transform_data",
  "notebook_path": "notebooks/Transform_Data",
  "existing_cluster_id": "0123-456789-example",
  "depends_on": ["extract_data"],
  "base_parameters": {"story_id": "NLSDIG-123"},
  "description": "Transform the released dataset.",
  "timeout_seconds": 3600,
  "max_retries": 1,
  "min_retry_interval_millis": 60000,
  "retry_on_timeout": false
}
```

Required fields are `task_key`, `notebook_path`, and `existing_cluster_id`.
`depends_on` is optional and defaults to an empty list. Every task with an empty
dependency list automatically depends on `set_task_values`. The utility rejects
duplicate task keys, unknown dependencies, self-dependencies, and cycles.

- Workspace notebook paths must be absolute and begin with `/`.
- Git notebook paths must be relative to the repository root.
- Each task explicitly selects its own existing cluster ID.

See `examples/tasks_workspace.json` and `examples/tasks_git.json` for complete
single-chain and branched-DAG examples.

## Action behavior

| Action | Behavior |
| --- | --- |
| `CREATE` | Creates a new job and fails if that exact name already exists. |
| `UPDATE` | Replaces the complete job definition while preserving the job ID. Internally this uses Jobs `reset`, preventing omitted old tasks from surviving the release. |
| `RE_CREATE` | Validates and creates the replacement first, then deletes the prior job. The replacement receives a new job ID, and this ordering protects the old job if creation fails. |
| `DELETE` | Deletes the entire resolved job. |
| `RUN` | Starts the existing job and optionally waits for completion. |

Job lookup accepts an ID, an exact case-insensitive name, or both. If both are
provided, they must identify the same job. Duplicate names require `job_id`.

`RUN` executes the Task Values notebook already stored in the job; it does not
rewrite the environment or behavior. Use `UPDATE` or `RE_CREATE` first when you
need a different Task Values path. `run_after_change=true` can run immediately
after a successful create, update, or recreate operation.

## Recommended release sequence

1. Select the action, source, environment, Task Value behavior, Git reference
   (when applicable), clusters, paths, and dependencies.
2. Keep `dry_run=true` and run the operator notebook.
3. Review `job_settings`, especially the Task Values path, Git branch/tag,
   notebook paths, clusters, and dependency graph.
4. Set `dry_run=false` and run again.
5. Use `run_after_change=true` if deployment and execution should happen in one
   notebook run.

## References

- [Databricks SDK for Python: Jobs API](https://databricks-sdk-py.readthedocs.io/en/latest/workspace/jobs/jobs.html)
- [Databricks SDK Jobs data classes](https://databricks-sdk-py.readthedocs.io/en/latest/dbdataclasses/jobs.html)
- [Databricks SDK long-running operations](https://databricks-sdk-py.readthedocs.io/en/latest/wait.html)

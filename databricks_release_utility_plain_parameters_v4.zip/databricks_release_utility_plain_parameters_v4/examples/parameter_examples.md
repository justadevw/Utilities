# Parameter Examples

These values are entered directly in the widgets on
`02_release_workflow_plain_parameters_v4`.

The notebook creates 24 widgets. If it reports that all 24 are ready but the
header does not show all of them, use the widget panel settings to **Reset
Layout**.

## Workspace source: sequential workflow

| Parameter | Value |
| --- | --- |
| `source` | `WORKSPACE` |
| `notebook_paths` | `/Workspace/Release/Extract;/Workspace/Release/Transform;/Workspace/Release/Publish` |
| `notebook_compute_ids` | `cluster-extract;cluster-transform;cluster-publish` |
| `notebook_task_keys` | `extract;transform;publish` |
| `notebook_dependencies` | `2=1;3=2` |

## Git source: branched workflow

| Parameter | Value |
| --- | --- |
| `source` | `GIT` |
| `git_reference_type` | `TAG` |
| `git_reference` | `v2.4.0` |
| `notebook_paths` | `notebooks/Extract;notebooks/Transform_Customers;notebooks/Transform_Suppliers;notebooks/Publish` |
| `notebook_compute_ids` | `cluster-1;cluster-2;cluster-3;cluster-4` |
| `notebook_task_keys` | `extract;customers;suppliers;publish` |
| `notebook_dependencies` | `2=1;3=1;4=2,3` |

In both examples, every root notebook automatically depends on the generated
`set_task_values` task.

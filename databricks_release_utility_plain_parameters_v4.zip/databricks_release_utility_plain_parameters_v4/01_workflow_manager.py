# Databricks notebook source
# MAGIC %md
# MAGIC # Databricks Workflow Manager
# MAGIC
# MAGIC Reusable classes for validating, creating, replacing, deleting, and running
# MAGIC Databricks workflow jobs. Import this notebook from the release notebook with
# MAGIC `%run ./01_workflow_manager`.

# COMMAND ----------

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import timedelta
from enum import Enum
import re
from typing import Any, Dict, List, Mapping, Optional, Sequence, Tuple, Type, TypeVar

try:
    from databricks.sdk import WorkspaceClient
    from databricks.sdk.service import jobs
except ImportError as exc:  # pragma: no cover - evaluated on Databricks compute
    raise ImportError(
        "The Databricks SDK for Python is required. Install 'databricks-sdk' on "
        "the compute resource that runs this notebook."
    ) from exc


# COMMAND ----------

class WorkflowValidationError(ValueError):
    """Raised when a workflow definition cannot produce a valid Databricks job."""


class JobNotFoundError(LookupError):
    """Raised when no job matches the supplied job ID or name."""


class AmbiguousJobNameError(LookupError):
    """Raised when a job name resolves to more than one Databricks job."""


class JobAlreadyExistsError(RuntimeError):
    """Raised when CREATE is requested for a job name that already exists."""


class NotebookSource(str, Enum):
    GIT = "GIT"
    WORKSPACE = "WORKSPACE"


class GitReferenceType(str, Enum):
    BRANCH = "BRANCH"
    TAG = "TAG"


class TaskValueBehavior(str, Enum):
    CREATE = "CREATE"
    UPDATE = "UPDATE"
    RE_CREATE = "RE_CREATE"


class ReleaseEnvironment(str, Enum):
    DEV = "DEV"
    QA = "QA"
    PROD = "PROD"


EnumType = TypeVar("EnumType", bound=Enum)


def parse_enum(enum_type: Type[EnumType], value: Any, field_name: str) -> EnumType:
    """Parse an enum value case-insensitively and return a clear validation error."""
    if isinstance(value, enum_type):
        return value
    normalized = str(value or "").strip().upper()
    try:
        return enum_type(normalized)
    except ValueError as exc:
        allowed = ", ".join(member.value for member in enum_type)
        raise WorkflowValidationError(
            f"{field_name} must be one of: {allowed}. Received: {value!r}."
        ) from exc


def parse_bool(value: Any, field_name: str) -> bool:
    """Parse common Boolean representations used by Databricks text widgets."""
    if isinstance(value, bool):
        return value
    normalized = str(value or "").strip().lower()
    if normalized in {"true", "1", "yes", "y", "on"}:
        return True
    if normalized in {"false", "0", "no", "n", "off"}:
        return False
    raise WorkflowValidationError(
        f"{field_name} must be ON/OFF or true/false. Received: {value!r}."
    )


# COMMAND ----------

@dataclass(frozen=True)
class GitReference:
    """Static repository configuration plus the branch or tag selected per release."""

    url: str
    provider: str
    reference_type: GitReferenceType
    reference: str

    def validate(self) -> "GitReference":
        if not self.url.strip() or self.url.startswith("REPLACE_"):
            raise WorkflowValidationError(
                "GIT_URL must be set to the repository URL before using source=GIT."
            )
        if not self.provider.strip():
            raise WorkflowValidationError("GIT_PROVIDER cannot be empty.")
        try:
            jobs.GitProvider(self.provider.strip().upper())
        except ValueError as exc:
            allowed = ", ".join(provider.value for provider in jobs.GitProvider)
            raise WorkflowValidationError(
                f"Unsupported GIT_PROVIDER {self.provider!r}. Allowed values: {allowed}."
            ) from exc
        if not self.reference.strip():
            raise WorkflowValidationError(
                "A Git branch or tag value is required when source=GIT."
            )
        return self


@dataclass(frozen=True)
class NotebookTaskDefinition:
    """User-facing definition of one released notebook task."""

    task_key: str
    notebook_path: str
    existing_cluster_id: str
    depends_on: Tuple[str, ...] = field(default_factory=tuple)
    base_parameters: Mapping[str, str] = field(default_factory=dict)
    description: Optional[str] = None
    timeout_seconds: int = 0
    max_retries: int = 0
    min_retry_interval_millis: int = 0
    retry_on_timeout: bool = False

    @classmethod
    def from_mapping(cls, raw: Mapping[str, Any]) -> "NotebookTaskDefinition":
        if not isinstance(raw, Mapping):
            raise WorkflowValidationError(
                f"Each task definition must be a mapping. Received: {raw!r}."
            )

        allowed_fields = {
            "task_key",
            "notebook_path",
            "existing_cluster_id",
            "depends_on",
            "base_parameters",
            "description",
            "timeout_seconds",
            "max_retries",
            "min_retry_interval_millis",
            "retry_on_timeout",
        }
        unknown_fields = sorted(set(raw) - allowed_fields)
        if unknown_fields:
            raise WorkflowValidationError(
                "Unknown task field(s): " + ", ".join(unknown_fields)
            )

        missing_fields = [
            name
            for name in ("task_key", "notebook_path", "existing_cluster_id")
            if not str(raw.get(name, "")).strip()
        ]
        if missing_fields:
            raise WorkflowValidationError(
                "Task is missing required field(s): " + ", ".join(missing_fields)
            )

        dependencies = raw.get("depends_on", [])
        if not isinstance(dependencies, list) or not all(
            isinstance(item, str) and item.strip() for item in dependencies
        ):
            raise WorkflowValidationError(
                f"depends_on for task {raw.get('task_key')!r} must be a list of task-key strings."
            )
        normalized_dependencies = tuple(item.strip() for item in dependencies)
        if len(set(normalized_dependencies)) != len(normalized_dependencies):
            raise WorkflowValidationError(
                f"Task {raw.get('task_key')!r} contains duplicate dependencies."
            )

        base_parameters = raw.get("base_parameters", {})
        if not isinstance(base_parameters, Mapping) or not all(
            isinstance(key, str) and isinstance(value, str)
            for key, value in base_parameters.items()
        ):
            raise WorkflowValidationError(
                f"base_parameters for task {raw.get('task_key')!r} must be a string-to-string object."
            )

        try:
            timeout_seconds = int(raw.get("timeout_seconds", 0))
            max_retries = int(raw.get("max_retries", 0))
            min_retry_interval_millis = int(raw.get("min_retry_interval_millis", 0))
        except (TypeError, ValueError) as exc:
            raise WorkflowValidationError(
                f"Task {raw.get('task_key')!r} contains a non-integer timeout or retry value."
            ) from exc

        if timeout_seconds < 0:
            raise WorkflowValidationError("timeout_seconds cannot be negative.")
        if max_retries < -1:
            raise WorkflowValidationError("max_retries cannot be less than -1.")
        if min_retry_interval_millis < 0:
            raise WorkflowValidationError(
                "min_retry_interval_millis cannot be negative."
            )

        retry_on_timeout = raw.get("retry_on_timeout", False)
        if not isinstance(retry_on_timeout, bool):
            raise WorkflowValidationError(
                f"retry_on_timeout for task {raw.get('task_key')!r} must be a Boolean."
            )

        return cls(
            task_key=str(raw["task_key"]).strip(),
            notebook_path=str(raw["notebook_path"]).strip(),
            existing_cluster_id=str(raw["existing_cluster_id"]).strip(),
            depends_on=normalized_dependencies,
            base_parameters=dict(base_parameters),
            description=(
                str(raw["description"]).strip()
                if raw.get("description") is not None
                else None
            ),
            timeout_seconds=timeout_seconds,
            max_retries=max_retries,
            min_retry_interval_millis=min_retry_interval_millis,
            retry_on_timeout=retry_on_timeout,
        )


def parse_parameter_list(value: Any, field_name: str) -> List[str]:
    """Parse semicolon- or newline-separated Databricks parameter values."""
    if value is None:
        return []
    if not isinstance(value, str):
        raise WorkflowValidationError(f"{field_name} must be a string parameter.")
    return [
        item.strip()
        for item in re.split(r"[;\r\n]+", value)
        if item.strip()
    ]


def parse_key_value_parameter(value: Any, field_name: str) -> Dict[str, str]:
    """Parse a semicolon-separated `key=value;key2=value2` parameter."""
    entries = parse_parameter_list(value, field_name)
    result: Dict[str, str] = {}
    for entry in entries:
        if "=" not in entry:
            raise WorkflowValidationError(
                f"Each {field_name} entry must use key=value. Invalid entry: {entry!r}."
            )
        key, item_value = (part.strip() for part in entry.split("=", 1))
        if not key or not item_value:
            raise WorkflowValidationError(
                f"Each {field_name} entry needs a non-empty key and value. "
                f"Invalid entry: {entry!r}."
            )
        if key in result:
            raise WorkflowValidationError(
                f"Duplicate key {key!r} in {field_name}."
            )
        result[key] = item_value
    return result


def notebook_tasks_from_parameters(
    *,
    notebook_paths: str,
    notebook_compute_ids: str,
    notebook_task_keys: str = "",
    notebook_dependencies: str = "",
) -> Tuple[NotebookTaskDefinition, ...]:
    """Build task definitions from ordinary Databricks string parameters.

    Paths, compute IDs, and optional task keys are semicolon-separated parallel
    lists. Dependencies use one-based positions, for example `2=1;3=1,2`.
    """
    paths = parse_parameter_list(notebook_paths, "notebook_paths")
    compute_ids = parse_parameter_list(
        notebook_compute_ids, "notebook_compute_ids"
    )
    supplied_task_keys = parse_parameter_list(
        notebook_task_keys, "notebook_task_keys"
    )

    if not paths:
        raise WorkflowValidationError(
            "notebook_paths must contain at least one notebook path."
        )
    if len(compute_ids) != len(paths):
        raise WorkflowValidationError(
            "notebook_compute_ids must contain exactly one compute ID per "
            f"notebook path. Received {len(compute_ids)} compute ID(s) for "
            f"{len(paths)} path(s)."
        )
    if supplied_task_keys and len(supplied_task_keys) != len(paths):
        raise WorkflowValidationError(
            "When notebook_task_keys is supplied, it must contain exactly one "
            f"task key per notebook path. Received {len(supplied_task_keys)} "
            f"key(s) for {len(paths)} path(s)."
        )

    task_keys = supplied_task_keys or [
        _default_task_key(position, path)
        for position, path in enumerate(paths, start=1)
    ]
    dependencies_by_position = _parse_dependency_positions(
        notebook_dependencies, len(paths)
    )

    return tuple(
        NotebookTaskDefinition(
            task_key=task_keys[position - 1],
            notebook_path=path,
            existing_cluster_id=compute_ids[position - 1],
            depends_on=tuple(
                task_keys[parent_position - 1]
                for parent_position in dependencies_by_position.get(position, ())
            ),
        )
        for position, path in enumerate(paths, start=1)
    )


def _default_task_key(position: int, notebook_path: str) -> str:
    notebook_name = notebook_path.rstrip("/").rsplit("/", 1)[-1]
    notebook_name = re.sub(
        r"\.(py|ipynb|scala|sql|r)$", "", notebook_name, flags=re.IGNORECASE
    )
    slug = re.sub(r"[^A-Za-z0-9_-]+", "_", notebook_name).strip("_-")
    prefix = f"task_{position}_"
    return prefix + (slug or "notebook")[: 100 - len(prefix)]


def _parse_dependency_positions(
    value: str, notebook_count: int
) -> Dict[int, Tuple[int, ...]]:
    dependencies: Dict[int, Tuple[int, ...]] = {}
    for entry in parse_parameter_list(value, "notebook_dependencies"):
        if "=" not in entry:
            raise WorkflowValidationError(
                "Each notebook_dependencies entry must use child=parent or "
                f"child=parent1,parent2. Invalid entry: {entry!r}."
            )
        child_raw, parents_raw = (part.strip() for part in entry.split("=", 1))
        try:
            child_position = int(child_raw)
            parent_positions = tuple(
                int(parent.strip())
                for parent in parents_raw.split(",")
                if parent.strip()
            )
        except ValueError as exc:
            raise WorkflowValidationError(
                "notebook_dependencies must use one-based notebook numbers. "
                f"Invalid entry: {entry!r}."
            ) from exc

        if not parent_positions:
            raise WorkflowValidationError(
                f"Dependency entry {entry!r} does not contain a parent notebook number."
            )
        if not 1 <= child_position <= notebook_count:
            raise WorkflowValidationError(
                f"Dependency child {child_position} is outside the valid range "
                f"1-{notebook_count}."
            )
        if child_position in dependencies:
            raise WorkflowValidationError(
                f"Notebook {child_position} appears more than once in notebook_dependencies."
            )
        if len(set(parent_positions)) != len(parent_positions):
            raise WorkflowValidationError(
                f"Notebook {child_position} contains duplicate parent numbers."
            )
        for parent_position in parent_positions:
            if not 1 <= parent_position <= notebook_count:
                raise WorkflowValidationError(
                    f"Dependency parent {parent_position} is outside the valid "
                    f"range 1-{notebook_count}."
                )
            if parent_position == child_position:
                raise WorkflowValidationError(
                    f"Notebook {child_position} cannot depend on itself."
                )
        dependencies[child_position] = parent_positions
    return dependencies


@dataclass(frozen=True)
class WorkflowDefinition:
    """Complete desired state for a managed Databricks workflow job."""

    job_name: str
    source: NotebookSource
    environment: ReleaseEnvironment
    task_value_behavior: TaskValueBehavior
    task_values_base_path: str
    task_values_cluster_id: str
    tasks: Tuple[NotebookTaskDefinition, ...]
    git_reference: Optional[GitReference] = None
    task_values_task_key: str = "set_task_values"
    description: str = "Managed by the Databricks Release Utility."
    max_concurrent_runs: int = 1
    timeout_seconds: int = 0
    tags: Mapping[str, str] = field(default_factory=dict)

    @property
    def task_values_notebook_path(self) -> str:
        suffix = {
            TaskValueBehavior.CREATE: "Create",
            TaskValueBehavior.UPDATE: "Update",
            TaskValueBehavior.RE_CREATE: "Re_Create",
        }[self.task_value_behavior]
        base_path = "/" + self.task_values_base_path.strip().strip("/")
        return f"{base_path}/Set_TaskValues_{self.environment.value}_{suffix}"

    def validate(self) -> "WorkflowDefinition":
        if not self.job_name.strip():
            raise WorkflowValidationError("job_name cannot be empty.")
        if len(self.job_name.encode("utf-8")) > 4096:
            raise WorkflowValidationError("job_name exceeds the Databricks 4096-byte limit.")
        if not self.task_values_base_path.strip().strip("/"):
            raise WorkflowValidationError("task_values_base_path cannot be empty.")
        if not self.task_values_cluster_id.strip():
            raise WorkflowValidationError("task_values_cluster_id cannot be empty.")
        if self.task_values_cluster_id.strip().startswith("REPLACE_"):
            raise WorkflowValidationError(
                "Replace the Task Values cluster placeholder with an existing cluster ID."
            )
        if not self.tasks:
            raise WorkflowValidationError("At least one released notebook task is required.")
        if len(self.tasks) + 1 > 1000:
            raise WorkflowValidationError(
                "A Databricks job supports at most 1000 tasks, including set_task_values."
            )
        if self.max_concurrent_runs < 1:
            raise WorkflowValidationError("max_concurrent_runs must be at least 1.")
        if self.timeout_seconds < 0:
            raise WorkflowValidationError("Job timeout_seconds cannot be negative.")
        if not re.fullmatch(r"[A-Za-z0-9_-]{1,100}", self.task_values_task_key):
            raise WorkflowValidationError(
                "task_values_task_key must contain 1-100 letters, numbers, underscores, or hyphens."
            )
        if not self.task_values_notebook_path.startswith("/"):
            raise WorkflowValidationError(
                "The generated Task Values notebook path must be absolute."
            )

        if self.source is NotebookSource.GIT:
            if self.git_reference is None:
                raise WorkflowValidationError(
                    "git_reference is required when source=GIT."
                )
            self.git_reference.validate()

        task_keys = [task.task_key for task in self.tasks]
        if len(set(task_keys)) != len(task_keys):
            duplicates = sorted({key for key in task_keys if task_keys.count(key) > 1})
            raise WorkflowValidationError(
                "Duplicate task_key value(s): " + ", ".join(duplicates)
            )
        if self.task_values_task_key in task_keys:
            raise WorkflowValidationError(
                f"{self.task_values_task_key!r} is reserved for the Task Values notebook."
            )

        known_keys = set(task_keys)
        dependency_graph: Dict[str, Tuple[str, ...]] = {}
        for task in self.tasks:
            if not re.fullmatch(r"[A-Za-z0-9_-]{1,100}", task.task_key):
                raise WorkflowValidationError(
                    f"Invalid task_key {task.task_key!r}; use 1-100 letters, numbers, underscores, or hyphens."
                )
            if task.task_key in task.depends_on:
                raise WorkflowValidationError(
                    f"Task {task.task_key!r} cannot depend on itself."
                )
            if task.existing_cluster_id.strip().startswith("REPLACE_"):
                raise WorkflowValidationError(
                    f"Replace the cluster placeholder for task {task.task_key!r} "
                    "with an existing cluster ID."
                )
            unknown_dependencies = sorted(set(task.depends_on) - known_keys)
            if unknown_dependencies:
                raise WorkflowValidationError(
                    f"Task {task.task_key!r} has unknown dependency/dependencies: "
                    + ", ".join(unknown_dependencies)
                )

            if self.source is NotebookSource.WORKSPACE:
                if not task.notebook_path.startswith("/"):
                    raise WorkflowValidationError(
                        f"Workspace notebook path {task.notebook_path!r} must be absolute and begin with '/'."
                    )
            elif task.notebook_path.startswith("/"):
                raise WorkflowValidationError(
                    f"Git notebook path {task.notebook_path!r} must be relative to the repository root."
                )

            dependency_graph[task.task_key] = task.depends_on

        self._validate_acyclic(dependency_graph)

        merged_tags = dict(self.tags)
        merged_tags.update(
            {
                "managed_by": "databricks_release_utility",
                "environment": self.environment.value,
                "task_value_behavior": self.task_value_behavior.value,
                "source": self.source.value,
            }
        )
        if not all(isinstance(key, str) and isinstance(value, str) for key, value in merged_tags.items()):
            raise WorkflowValidationError("All job tag keys and values must be strings.")
        if len(merged_tags) > 25:
            raise WorkflowValidationError(
                "Databricks permits at most 25 job tags, including the four utility-managed tags."
            )
        return self

    @staticmethod
    def _validate_acyclic(graph: Mapping[str, Sequence[str]]) -> None:
        visiting: set[str] = set()
        visited: set[str] = set()

        def visit(task_key: str, trail: Tuple[str, ...]) -> None:
            if task_key in visiting:
                cycle_start = trail.index(task_key) if task_key in trail else 0
                cycle = trail[cycle_start:] + (task_key,)
                raise WorkflowValidationError(
                    "Task dependency cycle detected: " + " -> ".join(cycle)
                )
            if task_key in visited:
                return
            visiting.add(task_key)
            for dependency in graph[task_key]:
                visit(dependency, trail + (task_key,))
            visiting.remove(task_key)
            visited.add(task_key)

        for key in graph:
            visit(key, tuple())


# COMMAND ----------

class DatabricksWorkflowManager:
    """Create, deterministically update, recreate, delete, and run workflow jobs."""

    def __init__(self, client: Optional[WorkspaceClient] = None) -> None:
        self.client = client or WorkspaceClient()

    def build_job_settings(self, definition: WorkflowDefinition) -> jobs.JobSettings:
        """Validate a definition and convert it to typed Databricks SDK settings."""
        definition.validate()

        task_values_task = jobs.Task(
            task_key=definition.task_values_task_key,
            description=(
                f"Set Task Values for {definition.environment.value} / "
                f"{definition.task_value_behavior.value}."
            ),
            existing_cluster_id=definition.task_values_cluster_id,
            notebook_task=jobs.NotebookTask(
                notebook_path=definition.task_values_notebook_path,
                source=jobs.Source.WORKSPACE,
            ),
            timeout_seconds=0,
            max_retries=0,
        )

        source = jobs.Source(definition.source.value)
        released_tasks: List[jobs.Task] = []
        for task in definition.tasks:
            # Every graph root depends on the Task Values notebook. Non-root tasks
            # inherit that ordering transitively through the explicit DAG.
            dependencies = task.depends_on or (definition.task_values_task_key,)
            released_tasks.append(
                jobs.Task(
                    task_key=task.task_key,
                    description=task.description,
                    existing_cluster_id=task.existing_cluster_id,
                    depends_on=[
                        jobs.TaskDependency(task_key=dependency)
                        for dependency in dependencies
                    ],
                    notebook_task=jobs.NotebookTask(
                        notebook_path=task.notebook_path,
                        base_parameters=(
                            dict(task.base_parameters)
                            if task.base_parameters
                            else None
                        ),
                        source=source,
                    ),
                    timeout_seconds=task.timeout_seconds,
                    max_retries=task.max_retries,
                    min_retry_interval_millis=task.min_retry_interval_millis,
                    retry_on_timeout=task.retry_on_timeout,
                )
            )

        git_source = None
        if definition.source is NotebookSource.GIT:
            git_reference = definition.git_reference
            assert git_reference is not None  # enforced by validate()
            git_kwargs: Dict[str, Any] = {
                "git_url": git_reference.url,
                "git_provider": jobs.GitProvider(git_reference.provider.upper()),
            }
            if git_reference.reference_type is GitReferenceType.BRANCH:
                git_kwargs["git_branch"] = git_reference.reference
            else:
                git_kwargs["git_tag"] = git_reference.reference
            git_source = jobs.GitSource(**git_kwargs)

        tags = dict(definition.tags)
        tags.update(
            {
                "managed_by": "databricks_release_utility",
                "environment": definition.environment.value,
                "task_value_behavior": definition.task_value_behavior.value,
                "source": definition.source.value,
            }
        )

        return jobs.JobSettings(
            name=definition.job_name,
            description=definition.description,
            tasks=[task_values_task, *released_tasks],
            git_source=git_source,
            max_concurrent_runs=definition.max_concurrent_runs,
            timeout_seconds=definition.timeout_seconds,
            tags=tags,
        )

    def preview(self, definition: WorkflowDefinition) -> Dict[str, Any]:
        """Return the exact SDK request settings without changing Databricks state."""
        return self.build_job_settings(definition).as_dict()

    def find_job(
        self,
        *,
        job_id: Optional[int] = None,
        job_name: Optional[str] = None,
    ) -> Any:
        """Resolve a job by ID, exact case-insensitive name, or both."""
        normalized_name = str(job_name or "").strip() or None
        normalized_id = self._normalize_job_id(job_id)
        if normalized_id is None and normalized_name is None:
            raise WorkflowValidationError("Provide either job_id or job_name.")

        if normalized_id is not None:
            resolved = self.client.jobs.get(job_id=normalized_id)
            resolved_name = self._job_name(resolved)
            if normalized_name and resolved_name.lower() != normalized_name.lower():
                raise WorkflowValidationError(
                    f"job_id={normalized_id} belongs to {resolved_name!r}, not {normalized_name!r}."
                )
            return resolved

        matches = self._jobs_by_name(normalized_name or "")
        if not matches:
            raise JobNotFoundError(f"No Databricks job named {normalized_name!r} was found.")
        if len(matches) > 1:
            ids = ", ".join(str(item.job_id) for item in matches)
            raise AmbiguousJobNameError(
                f"Multiple jobs are named {normalized_name!r} (job IDs: {ids}). Use job_id."
            )
        return self.client.jobs.get(job_id=matches[0].job_id)

    def create_job(self, definition: WorkflowDefinition) -> Dict[str, Any]:
        """Create a job and fail if the exact job name already exists."""
        settings = self.build_job_settings(definition)
        existing = self._jobs_by_name(definition.job_name)
        if existing:
            ids = ", ".join(str(item.job_id) for item in existing)
            raise JobAlreadyExistsError(
                f"Job {definition.job_name!r} already exists (job ID(s): {ids})."
            )

        response = self.client.jobs.create(
            name=settings.name,
            description=settings.description,
            tasks=settings.tasks,
            git_source=settings.git_source,
            max_concurrent_runs=settings.max_concurrent_runs,
            timeout_seconds=settings.timeout_seconds,
            tags=settings.tags,
        )
        return {
            "action": "CREATE",
            "job_id": response.job_id,
            "job_name": definition.job_name,
        }

    def update_job(
        self,
        definition: WorkflowDefinition,
        *,
        job_id: Optional[int] = None,
        job_name: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Fully replace job settings while preserving the existing job ID."""
        settings = self.build_job_settings(definition)
        existing = self.find_job(job_id=job_id, job_name=job_name)
        existing_id = existing.job_id

        collisions = [
            item
            for item in self._jobs_by_name(definition.job_name)
            if item.job_id != existing_id
        ]
        if collisions:
            ids = ", ".join(str(item.job_id) for item in collisions)
            raise JobAlreadyExistsError(
                f"Cannot rename/update job {existing_id} to {definition.job_name!r}; "
                f"that name belongs to job ID(s): {ids}."
            )

        # Reset is deliberate: Jobs API update merges task arrays and retains omitted
        # tasks. Reset makes the supplied release definition the complete desired state.
        self.client.jobs.reset(job_id=existing_id, new_settings=settings)
        return {
            "action": "UPDATE",
            "job_id": existing_id,
            "job_name": definition.job_name,
        }

    def recreate_job(
        self,
        definition: WorkflowDefinition,
        *,
        job_id: Optional[int] = None,
        job_name: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Delete an existing job and create a new job with a new job ID."""
        # Build and validate before deleting anything.
        settings = self.build_job_settings(definition)
        existing = self.find_job(job_id=job_id, job_name=job_name)
        previous_job_id = existing.job_id

        collisions = [
            item
            for item in self._jobs_by_name(definition.job_name)
            if item.job_id != previous_job_id
        ]
        if collisions:
            ids = ", ".join(str(item.job_id) for item in collisions)
            raise JobAlreadyExistsError(
                f"Cannot recreate as {definition.job_name!r}; that name belongs to "
                f"job ID(s): {ids}."
            )

        # Create the validated replacement before deleting the old job. Databricks
        # permits duplicate names, so this ordering prevents loss if creation fails.
        response = self.client.jobs.create(
            name=settings.name,
            description=settings.description,
            tasks=settings.tasks,
            git_source=settings.git_source,
            max_concurrent_runs=settings.max_concurrent_runs,
            timeout_seconds=settings.timeout_seconds,
            tags=settings.tags,
        )
        try:
            self.client.jobs.delete(job_id=previous_job_id)
        except Exception as exc:
            raise RuntimeError(
                f"Replacement job {response.job_id} was created, but old job "
                f"{previous_job_id} could not be deleted. Resolve the duplicate manually."
            ) from exc
        return {
            "action": "RE_CREATE",
            "previous_job_id": previous_job_id,
            "job_id": response.job_id,
            "job_name": definition.job_name,
        }

    def delete_job(
        self,
        *,
        job_id: Optional[int] = None,
        job_name: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Delete an entire workflow job."""
        existing = self.find_job(job_id=job_id, job_name=job_name)
        resolved_name = self._job_name(existing)
        self.client.jobs.delete(job_id=existing.job_id)
        return {
            "action": "DELETE",
            "job_id": existing.job_id,
            "job_name": resolved_name,
        }

    def run_job(
        self,
        *,
        job_id: Optional[int] = None,
        job_name: Optional[str] = None,
        wait: bool = False,
        timeout_minutes: int = 120,
        job_parameters: Optional[Mapping[str, str]] = None,
        idempotency_token: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Start a job, optionally waiting for its terminal state."""
        if timeout_minutes < 1:
            raise WorkflowValidationError("timeout_minutes must be at least 1.")
        if job_parameters is not None and not all(
            isinstance(key, str) and isinstance(value, str)
            for key, value in job_parameters.items()
        ):
            raise WorkflowValidationError(
                "job_parameters must contain only string keys and values."
            )
        if idempotency_token and len(idempotency_token) > 64:
            raise WorkflowValidationError(
                "idempotency_token cannot exceed 64 characters."
            )

        existing = self.find_job(job_id=job_id, job_name=job_name)
        run_kwargs: Dict[str, Any] = {"job_id": existing.job_id}
        if job_parameters:
            run_kwargs["job_parameters"] = dict(job_parameters)
        if idempotency_token:
            run_kwargs["idempotency_token"] = idempotency_token
        run_waiter = self.client.jobs.run_now(**run_kwargs)
        run_id = self._run_id(run_waiter)
        result: Dict[str, Any] = {
            "action": "RUN",
            "job_id": existing.job_id,
            "job_name": self._job_name(existing),
            "run_id": run_id,
            "waited_for_completion": wait,
        }

        if wait:
            run = run_waiter.result(timeout=timedelta(minutes=timeout_minutes))
            result["run"] = run.as_dict() if hasattr(run, "as_dict") else str(run)
            if result["run_id"] is None:
                result["run_id"] = getattr(run, "run_id", None)
        return result

    @staticmethod
    def _normalize_job_id(job_id: Optional[int]) -> Optional[int]:
        if job_id in (None, ""):
            return None
        try:
            normalized = int(job_id)
        except (TypeError, ValueError) as exc:
            raise WorkflowValidationError(
                f"job_id must be an integer. Received: {job_id!r}."
            ) from exc
        if normalized <= 0:
            raise WorkflowValidationError("job_id must be greater than zero.")
        return normalized

    def _jobs_by_name(self, job_name: str) -> List[Any]:
        normalized = job_name.strip().lower()
        if not normalized:
            return []
        return [
            item
            for item in self.client.jobs.list(name=job_name.strip(), expand_tasks=False)
            if self._job_name(item).lower() == normalized
        ]

    @staticmethod
    def _job_name(job: Any) -> str:
        settings = getattr(job, "settings", None)
        name = getattr(settings, "name", None) if settings is not None else None
        if not name:
            raise WorkflowValidationError(
                f"Databricks returned job {getattr(job, 'job_id', None)!r} without a name."
            )
        return str(name)

    @staticmethod
    def _run_id(waiter: Any) -> Optional[int]:
        direct = getattr(waiter, "run_id", None)
        if direct is not None:
            return direct
        response = getattr(waiter, "response", None)
        return getattr(response, "run_id", None) if response is not None else None

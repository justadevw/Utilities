# Databricks Story Release Utility — Plain Parameters v4

Version: `4.0.0-plain-parameters`

This utility creates and operates multi-task Databricks workflow jobs from two
Databricks source-format Python notebooks:

- `01_workflow_manager.py` contains validation, job construction, lookup,
  create, update, recreate, delete, and run methods.
- `02_release_workflow_plain_parameters_v4.py` is the operator notebook. Every
  release input is a regular Databricks widget parameter.

The `.py` source format is diff-friendly, works cleanly in Git, and can be
imported directly into Databricks as a notebook.

## Resulting workflow structure

The utility creates one workspace-sourced Task Values task followed by the
released notebook tasks:

```text
set_task_values
  -> every root notebook
       -> remaining notebooks according to notebook_dependencies
```

For example, `environment=QA` and `task_value_behavior=RE_CREATE` produces:

```text
/Workspace/Workflow_Task_Values/Set_TaskValues_QA_Re_Create
```

The fixed Task Values task key is `set_task_values`. Downstream notebooks that
retrieve values with `dbutils.jobs.taskValues.get(...)` must use that task key.
The utility does not assume or alter the individual keys set inside your Task
Values notebooks.

## One-time setup

1. Import the complete `databricks_release_utility_plain_parameters_v4` folder
   as a new Databricks workspace folder. Do not merge it into the older utility
   folder; the new folder and notebook names prevent reuse of saved parameters.
2. Open `02_release_workflow_plain_parameters_v4.py` and set the two repository
   constants:

   ```python
   GIT_URL = "https://your-git-host/organization/repository.git"
   GIT_PROVIDER = "GIT_HUB_ENTERPRISE"
   ```

3. Confirm that the compute resource running the utility has the Databricks SDK
   for Python. If needed, install the `databricks-sdk` package on that compute.
4. Confirm that the operator can create/manage jobs and use the selected
   clusters. For Git releases, the workspace must already have credentials for
   the static repository.

## Databricks parameters

The operator notebook defines all 24 parameters automatically. Its first setup
cell also removes obsolete parameters left by an older copy of the notebook
while preserving the values of the current parameters. Widget cleanup and
creation run before the workflow-manager notebook is loaded, so a manager setup
error cannot prevent the parameter panel from being repaired.

On its first run, the notebook reports
`Utility 4.0.0-plain-parameters: notebook parameters ready: 24 of 24`. If some
parameters are not visible, open the settings at the right end of the widget
panel and select **Reset Layout**.

| Parameter | Purpose |
| --- | --- |
| `workflow_action` | `CREATE`, `UPDATE`, `RE_CREATE`, `DELETE`, or `RUN` |
| `job_name` | Required for `CREATE`; optional for other actions when `job_id` is supplied |
| `job_id` | Optional exact job identifier; use it when names are duplicated |
| `source` | `WORKSPACE` or `GIT` for the released notebooks |
| `environment` | `DEV`, `QA`, or `PROD`; builds the Task Values notebook path |
| `task_value_behavior` | `CREATE`, `UPDATE`, or `RE_CREATE`; builds the Task Values notebook path |
| `git_reference_type` | `BRANCH` or `TAG` when `source=GIT` |
| `git_reference` | Selected branch or tag name |
| `task_values_base_path` | Defaults to `/Workspace/Workflow_Task_Values` |
| `task_values_cluster_id` | Existing compute used by the Task Values notebook |
| `notebook_paths` | One or more notebook paths separated by semicolons |
| `notebook_compute_ids` | One compute ID per notebook, in the same order, separated by semicolons |
| `notebook_task_keys` | Optional task keys in the same order, separated by semicolons |
| `notebook_dependencies` | Optional one-based dependency mappings such as `2=1;3=1,2` |
| `job_tags` | Optional `key=value;key2=value2` entries |
| `job_parameters` | Optional run parameters using `key=value;key2=value2` |
| `run_after_change` | `ON` runs the workflow after create, update, or recreate |
| `wait_for_run` | `ON` waits for the workflow run to finish |
| `dry_run` | `ON` validates and previews; `OFF` performs the selected action |

These are also valid notebook base parameters if the utility itself is invoked
from another Databricks workflow.

`workflow_action` and `task_value_behavior` are deliberately separate. For
example, an existing workflow can be updated (`workflow_action=UPDATE`) so its
data notebooks execute create behavior (`task_value_behavior=CREATE`).

## Supplying one or multiple notebooks

The notebook lists are positional. Separate entries with semicolons and keep
the paths, compute IDs, and optional task keys in the same order.

### One workspace notebook

```text
notebook_paths:
/Workspace/Release_Notebooks/Publish_Data

notebook_compute_ids:
0123-456789-cluster1

notebook_task_keys:
publish_data

notebook_dependencies:
[leave blank]
```

### Three Git notebooks in sequence

```text
notebook_paths:
notebooks/Extract;notebooks/Transform;notebooks/Publish

notebook_compute_ids:
cluster-1;cluster-2;cluster-3

notebook_task_keys:
extract;transform;publish

notebook_dependencies:
2=1;3=2
```

The dependency input uses one-based notebook positions:

- `2=1` means notebook 2 depends on notebook 1.
- `3=1,2` means notebook 3 depends on notebooks 1 and 2.
- Root notebooks are omitted from the dependency input. They automatically
  depend on `set_task_values`.

For a branched four-notebook workflow, use `2=1;3=1;4=2,3`.

`notebook_task_keys` is optional. When blank, readable keys are generated from
the notebook position and filename, such as `task_1_Extract`. The utility
rejects mismatched list lengths, duplicate task keys, invalid positions,
self-dependencies, unknown dependencies, and dependency cycles.

- Workspace notebook paths must be absolute and begin with `/`.
- Git notebook paths must be relative to the repository root.
- Every notebook must have an explicitly supplied existing compute ID.

## Action behavior

| Action | Behavior |
| --- | --- |
| `CREATE` | Creates a new job and fails if that exact name already exists. |
| `UPDATE` | Replaces the complete job definition while preserving the job ID. Internally this uses Jobs `reset`, preventing omitted old tasks from surviving the release. |
| `RE_CREATE` | Validates and creates the replacement first, then deletes the prior job. The replacement receives a new job ID. |
| `DELETE` | Deletes the entire resolved job. |
| `RUN` | Starts the existing job and optionally waits for completion. |

Job lookup accepts an ID, an exact case-insensitive name, or both. If both are
provided, they must identify the same job. Duplicate names require `job_id`.

`RUN` executes the Task Values notebook already stored in the job; it does not
rewrite the environment or behavior. Use `UPDATE` or `RE_CREATE` first when a
different Task Values path is required.

## Recommended release sequence

1. Enter the action, source, environment, behavior, notebook paths, matching
   compute IDs, and dependencies.
2. Keep `dry_run=ON` and run the operator notebook.
3. Review `job_settings`, especially the Task Values path, Git branch/tag,
   notebook paths, compute IDs, and dependency graph.
4. Set `dry_run=OFF` and run again.
5. Set `run_after_change=ON` when deployment and execution should happen in the
   same notebook run.

## References

- [Databricks SDK for Python: Jobs API](https://databricks-sdk-py.readthedocs.io/en/latest/workspace/jobs/jobs.html)
- [Databricks SDK Jobs data classes](https://databricks-sdk-py.readthedocs.io/en/latest/dbdataclasses/jobs.html)
- [Databricks SDK long-running operations](https://databricks-sdk-py.readthedocs.io/en/latest/wait.html)

from __future__ import annotations

import ast
from enum import Enum
import importlib.util
from pathlib import Path
from types import ModuleType, SimpleNamespace
import sys
import unittest


class _Model:
    def __init__(self, **kwargs):
        for key, value in kwargs.items():
            setattr(self, key, value)

    def as_dict(self):
        def convert(value):
            if isinstance(value, Enum):
                return value.value
            if isinstance(value, _Model):
                return value.as_dict()
            if isinstance(value, list):
                return [convert(item) for item in value]
            if isinstance(value, dict):
                return {key: convert(item) for key, item in value.items()}
            return value

        return {
            key: convert(value)
            for key, value in self.__dict__.items()
            if value is not None
        }


class _Source(str, Enum):
    GIT = "GIT"
    WORKSPACE = "WORKSPACE"


class _GitProvider(str, Enum):
    GIT_HUB = "GIT_HUB"
    GIT_HUB_ENTERPRISE = "GIT_HUB_ENTERPRISE"
    AZURE_DEV_OPS_SERVICES = "AZURE_DEV_OPS_SERVICES"


def _install_sdk_stubs():
    databricks_module = ModuleType("databricks")
    sdk_module = ModuleType("databricks.sdk")
    service_module = ModuleType("databricks.sdk.service")
    jobs_module = ModuleType("databricks.sdk.service.jobs")

    sdk_module.WorkspaceClient = type("WorkspaceClient", (), {})
    for name in ("Task", "NotebookTask", "TaskDependency", "GitSource", "JobSettings"):
        setattr(jobs_module, name, type(name, (_Model,), {}))
    jobs_module.Source = _Source
    jobs_module.GitProvider = _GitProvider
    service_module.jobs = jobs_module

    sys.modules["databricks"] = databricks_module
    sys.modules["databricks.sdk"] = sdk_module
    sys.modules["databricks.sdk.service"] = service_module
    sys.modules["databricks.sdk.service.jobs"] = jobs_module


_install_sdk_stubs()
MODULE_PATH = Path(__file__).parents[1] / "01_workflow_manager.py"
OPERATOR_PATH = (
    Path(__file__).parents[1] / "02_release_workflow_plain_parameters_v4.py"
)
SPEC = importlib.util.spec_from_file_location("workflow_manager", MODULE_PATH)
workflow_manager = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = workflow_manager
assert SPEC.loader is not None
SPEC.loader.exec_module(workflow_manager)


class _FakeWaiter:
    def __init__(self, run_id):
        self.run_id = run_id

    def result(self, timeout=None):
        return _Model(
            run_id=self.run_id,
            state=_Model(life_cycle_state="TERMINATED", result_state="SUCCESS"),
        )


class _FakeJobsApi:
    def __init__(self):
        self.records = {}
        self.next_job_id = 100
        self.next_run_id = 1000
        self.reset_calls = []
        self.deleted_ids = []

    def seed(self, job_id, name):
        self.records[job_id] = _Model(
            job_id=job_id,
            settings=_Model(name=name),
        )

    def list(self, name=None, expand_tasks=False):
        records = list(self.records.values())
        if name is None:
            return iter(records)
        return iter(
            item
            for item in records
            if item.settings.name.lower() == name.lower()
        )

    def get(self, job_id):
        return self.records[job_id]

    def create(self, **kwargs):
        job_id = self.next_job_id
        self.next_job_id += 1
        self.records[job_id] = _Model(
            job_id=job_id,
            settings=_Model(**kwargs),
        )
        return _Model(job_id=job_id)

    def reset(self, job_id, new_settings):
        self.reset_calls.append((job_id, new_settings))
        self.records[job_id] = _Model(job_id=job_id, settings=new_settings)

    def delete(self, job_id):
        self.deleted_ids.append(job_id)
        del self.records[job_id]

    def run_now(self, job_id, job_parameters=None, idempotency_token=None):
        assert job_id in self.records
        run_id = self.next_run_id
        self.next_run_id += 1
        return _FakeWaiter(run_id)


class _FakeClient:
    def __init__(self):
        self.jobs = _FakeJobsApi()


def _task(task_key, path, cluster_id="cluster-1", depends_on=()):
    return workflow_manager.NotebookTaskDefinition(
        task_key=task_key,
        notebook_path=path,
        existing_cluster_id=cluster_id,
        depends_on=tuple(depends_on),
    )


def _workspace_definition(name="Release Job"):
    return workflow_manager.WorkflowDefinition(
        job_name=name,
        source=workflow_manager.NotebookSource.WORKSPACE,
        environment=workflow_manager.ReleaseEnvironment.DEV,
        task_value_behavior=workflow_manager.TaskValueBehavior.CREATE,
        task_values_base_path="Workspace/Workflow_Task_Values",
        task_values_cluster_id="task-values-cluster",
        tasks=(
            _task("extract", "/Workspace/Notebooks/Extract"),
            _task(
                "publish",
                "/Workspace/Notebooks/Publish",
                cluster_id="cluster-2",
                depends_on=("extract",),
            ),
        ),
    )


class WorkflowManagerTests(unittest.TestCase):
    def test_plain_parameters_build_multiple_notebook_tasks(self):
        tasks = workflow_manager.notebook_tasks_from_parameters(
            notebook_paths=(
                "notebooks/Extract;notebooks/Transform.py;notebooks/Publish"
            ),
            notebook_compute_ids="cluster-1;cluster-2;cluster-3",
            notebook_dependencies="2=1;3=1,2",
        )

        self.assertEqual(
            [task.task_key for task in tasks],
            ["task_1_Extract", "task_2_Transform", "task_3_Publish"],
        )
        self.assertEqual(
            [task.existing_cluster_id for task in tasks],
            ["cluster-1", "cluster-2", "cluster-3"],
        )
        self.assertEqual(tasks[0].depends_on, ())
        self.assertEqual(tasks[1].depends_on, ("task_1_Extract",))
        self.assertEqual(
            tasks[2].depends_on,
            ("task_1_Extract", "task_2_Transform"),
        )

    def test_custom_task_keys_key_value_parameters_and_on_off(self):
        tasks = workflow_manager.notebook_tasks_from_parameters(
            notebook_paths="/Workspace/A\n/Workspace/B",
            notebook_compute_ids="cluster-a\ncluster-b",
            notebook_task_keys="extract;publish",
            notebook_dependencies="2=1",
        )
        self.assertEqual([task.task_key for task in tasks], ["extract", "publish"])
        self.assertEqual(tasks[1].depends_on, ("extract",))
        self.assertEqual(
            workflow_manager.parse_key_value_parameter(
                "story=NLSDIG-123;owner=team", "job_parameters"
            ),
            {"story": "NLSDIG-123", "owner": "team"},
        )
        self.assertTrue(workflow_manager.parse_bool("ON", "dry_run"))
        self.assertFalse(workflow_manager.parse_bool("OFF", "dry_run"))

    def test_plain_parameter_validation_is_clear(self):
        with self.assertRaisesRegex(
            workflow_manager.WorkflowValidationError, "one compute ID per"
        ):
            workflow_manager.notebook_tasks_from_parameters(
                notebook_paths="/Workspace/A;/Workspace/B",
                notebook_compute_ids="cluster-a",
            )

        with self.assertRaisesRegex(
            workflow_manager.WorkflowValidationError, "outside the valid range"
        ):
            workflow_manager.notebook_tasks_from_parameters(
                notebook_paths="/Workspace/A;/Workspace/B",
                notebook_compute_ids="cluster-a;cluster-b",
                notebook_dependencies="2=3",
            )

        with self.assertRaisesRegex(
            workflow_manager.WorkflowValidationError, "Duplicate key"
        ):
            workflow_manager.parse_key_value_parameter(
                "owner=one;owner=two", "job_tags"
            )

    def test_git_settings_include_mixed_sources_and_explicit_dependencies(self):
        definition = workflow_manager.WorkflowDefinition(
            job_name="Git Release",
            source=workflow_manager.NotebookSource.GIT,
            environment=workflow_manager.ReleaseEnvironment.QA,
            task_value_behavior=workflow_manager.TaskValueBehavior.RE_CREATE,
            task_values_base_path="/Workspace/Workflow_Task_Values/",
            task_values_cluster_id="task-values-cluster",
            tasks=(
                _task("extract", "notebooks/Extract", "cluster-a"),
                _task(
                    "publish",
                    "notebooks/Publish",
                    "cluster-b",
                    ("extract",),
                ),
            ),
            git_reference=workflow_manager.GitReference(
                url="https://git.example/repository.git",
                provider="GIT_HUB_ENTERPRISE",
                reference_type=workflow_manager.GitReferenceType.BRANCH,
                reference="release/NLSDIG-123",
            ),
        )

        settings = workflow_manager.DatabricksWorkflowManager(
            _FakeClient()
        ).build_job_settings(definition)

        self.assertEqual(len(settings.tasks), 3)
        self.assertEqual(
            settings.tasks[0].notebook_task.notebook_path,
            "/Workspace/Workflow_Task_Values/Set_TaskValues_QA_Re_Create",
        )
        self.assertEqual(settings.tasks[0].notebook_task.source, _Source.WORKSPACE)
        self.assertEqual(settings.tasks[1].notebook_task.source, _Source.GIT)
        self.assertEqual(
            [item.task_key for item in settings.tasks[1].depends_on],
            ["set_task_values"],
        )
        self.assertEqual(
            [item.task_key for item in settings.tasks[2].depends_on],
            ["extract"],
        )
        self.assertEqual(settings.tasks[2].existing_cluster_id, "cluster-b")
        self.assertEqual(settings.git_source.git_branch, "release/NLSDIG-123")
        self.assertEqual(settings.git_source.git_provider, _GitProvider.GIT_HUB_ENTERPRISE)

    def test_workspace_settings_do_not_include_git_source(self):
        settings = workflow_manager.DatabricksWorkflowManager(
            _FakeClient()
        ).build_job_settings(_workspace_definition())
        self.assertIsNone(settings.git_source)
        self.assertEqual(settings.tasks[1].notebook_task.source, _Source.WORKSPACE)

    def test_rejects_cycle_and_wrong_path_type(self):
        cyclic = workflow_manager.WorkflowDefinition(
            job_name="Cycle",
            source=workflow_manager.NotebookSource.WORKSPACE,
            environment=workflow_manager.ReleaseEnvironment.DEV,
            task_value_behavior=workflow_manager.TaskValueBehavior.UPDATE,
            task_values_base_path="/Workspace/Workflow_Task_Values",
            task_values_cluster_id="cluster-tv",
            tasks=(
                _task("a", "/Workspace/A", depends_on=("b",)),
                _task("b", "/Workspace/B", depends_on=("a",)),
            ),
        )
        with self.assertRaisesRegex(
            workflow_manager.WorkflowValidationError, "cycle"
        ):
            cyclic.validate()

        invalid_git_path = workflow_manager.WorkflowDefinition(
            job_name="Bad Git Path",
            source=workflow_manager.NotebookSource.GIT,
            environment=workflow_manager.ReleaseEnvironment.DEV,
            task_value_behavior=workflow_manager.TaskValueBehavior.UPDATE,
            task_values_base_path="/Workspace/Workflow_Task_Values",
            task_values_cluster_id="cluster-tv",
            tasks=(_task("a", "/Workspace/A"),),
            git_reference=workflow_manager.GitReference(
                url="https://git.example/repository.git",
                provider="GIT_HUB_ENTERPRISE",
                reference_type=workflow_manager.GitReferenceType.TAG,
                reference="v1.0.0",
            ),
        )
        with self.assertRaisesRegex(
            workflow_manager.WorkflowValidationError, "must be relative"
        ):
            invalid_git_path.validate()

    def test_create_update_recreate_delete_and_run(self):
        client = _FakeClient()
        manager = workflow_manager.DatabricksWorkflowManager(client)
        definition = _workspace_definition()

        created = manager.create_job(definition)
        self.assertEqual(created["job_id"], 100)
        with self.assertRaises(workflow_manager.JobAlreadyExistsError):
            manager.create_job(definition)

        updated_definition = _workspace_definition("Release Job")
        updated = manager.update_job(updated_definition, job_id=100)
        self.assertEqual(updated["job_id"], 100)
        self.assertEqual(client.jobs.reset_calls[0][0], 100)

        run = manager.run_job(job_name="Release Job", wait=True)
        self.assertEqual(run["run_id"], 1000)
        self.assertTrue(run["waited_for_completion"])
        self.assertEqual(run["run"]["state"]["result_state"], "SUCCESS")

        recreated = manager.recreate_job(updated_definition, job_name="Release Job")
        self.assertEqual(recreated["previous_job_id"], 100)
        self.assertEqual(recreated["job_id"], 101)
        self.assertIn(100, client.jobs.deleted_ids)

        deleted = manager.delete_job(job_id=101, job_name="Release Job")
        self.assertEqual(deleted["job_id"], 101)
        self.assertNotIn(101, client.jobs.records)

    def test_ambiguous_names_require_job_id(self):
        client = _FakeClient()
        client.jobs.seed(10, "Duplicate")
        client.jobs.seed(11, "Duplicate")
        manager = workflow_manager.DatabricksWorkflowManager(client)
        with self.assertRaises(workflow_manager.AmbiguousJobNameError):
            manager.find_job(job_name="duplicate")
        self.assertEqual(manager.find_job(job_id=11).job_id, 11)

    def test_task_mapping_rejects_unknown_fields_and_non_string_parameters(self):
        with self.assertRaisesRegex(
            workflow_manager.WorkflowValidationError, "Unknown task field"
        ):
            workflow_manager.NotebookTaskDefinition.from_mapping(
                {
                    "task_key": "a",
                    "notebook_path": "/Workspace/A",
                    "existing_cluster_id": "cluster",
                    "typo": True,
                }
            )
        with self.assertRaisesRegex(
            workflow_manager.WorkflowValidationError, "string-to-string"
        ):
            workflow_manager.NotebookTaskDefinition.from_mapping(
                {
                    "task_key": "a",
                    "notebook_path": "/Workspace/A",
                    "existing_cluster_id": "cluster",
                    "base_parameters": {"number": 1},
                }
            )

    def test_placeholders_and_unknown_git_provider_are_rejected(self):
        placeholder_definition = workflow_manager.WorkflowDefinition(
            job_name="Placeholder",
            source=workflow_manager.NotebookSource.WORKSPACE,
            environment=workflow_manager.ReleaseEnvironment.DEV,
            task_value_behavior=workflow_manager.TaskValueBehavior.CREATE,
            task_values_base_path="/Workspace/Workflow_Task_Values",
            task_values_cluster_id="REPLACE_WITH_CLUSTER_ID",
            tasks=(_task("a", "/Workspace/A"),),
        )
        with self.assertRaisesRegex(
            workflow_manager.WorkflowValidationError, "placeholder"
        ):
            placeholder_definition.validate()

        bad_provider = workflow_manager.GitReference(
            url="https://git.example/repository.git",
            provider="NOT_A_PROVIDER",
            reference_type=workflow_manager.GitReferenceType.BRANCH,
            reference="main",
        )
        with self.assertRaisesRegex(
            workflow_manager.WorkflowValidationError, "Unsupported GIT_PROVIDER"
        ):
            bad_provider.validate()


class OperatorNotebookTests(unittest.TestCase):
    def test_operator_has_only_the_expected_plain_widgets(self):
        source = OPERATOR_PATH.read_text(encoding="utf-8")

        tree = ast.parse(source)
        expected_names = None
        created_names = []
        for node in ast.walk(tree):
            if isinstance(node, ast.Assign) and any(
                isinstance(target, ast.Name)
                and target.id == "EXPECTED_WIDGET_NAMES"
                for target in node.targets
            ):
                expected_names = ast.literal_eval(node.value)
            if (
                isinstance(node, ast.Call)
                and isinstance(node.func, ast.Name)
                and node.func.id in {"ensure_text_widget", "ensure_dropdown_widget"}
                and node.args
                and isinstance(node.args[0], ast.Constant)
                and isinstance(node.args[0].value, str)
            ):
                created_names.append(node.args[0].value)

        self.assertIsNotNone(expected_names)
        self.assertEqual(len(expected_names), 24)
        self.assertEqual(len(set(expected_names)), 24)
        self.assertEqual(set(created_names), set(expected_names))
        self.assertIn(
            "dbutils.widgets.remove(obsolete_widget_name)",
            source,
        )


if __name__ == "__main__":
    unittest.main()
